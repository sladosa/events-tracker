"""
Events Tracker - Source Package
================================
Created: 2025-11-15 18:30 UTC
Last Modified: 2025-11-15 18:30 UTC
Python: 3.11

Description:
Main package for Events Tracker modules.
"""

__version__ = "1.0.0"
__author__ = "Events Tracker Team"
